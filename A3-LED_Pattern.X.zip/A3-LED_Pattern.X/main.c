/*
 * File:   main.c
 * Author: Monica.s
 * Date:31.07.2024
 * Problem Statement : Write a Embedded C program to display the multiple patterns on the LEDs controlled by the switches.
 *                     For every switch, dedicate a LEDs glow pattern.The pattern should change on key press
 */


#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF

static void init_config(void) {
    /*To keep all LEDS OFF initially*/
    LED_ARRAY1 = OFF;
    
    /*To configure PORTD as output PORT*/
    LED_ARRAY1_DDR = 0x00; 
    TRISD=0x00;
    //PORTD=0x00;
    /* Initializing digital keypad */
    init_digital_keypad();

}

void main(void) {
    //Variable declaration
    unsigned char key, key_copy;
    
    init_config();

    while (1) {
        
        /*To read key press*/
        key = read_digital_keypad(LEVEL);
        
        /*If switch is pressed, then only update key_copy*/
        if (key != ALL_RELEASED)
        {
            key_copy = key;
        }
        glow_on_press(key_copy);
    }

    return;
}

void glow_on_press(unsigned char key) {
    static unsigned char flag = 0;
    static unsigned int wait = 0;
    static int i = 0;

    if (wait++ == 10000) {
        wait = 0;
        flag = !flag;

        if (key == SW1) {
            if (i < 8) {
                // Condition for left ON
                LED_ARRAY1 = (LED_ARRAY1 << 1) | 1;
                i++;
            } else if (i >= 8 && i < 16) {
                // Condition for left OFF
                LED_ARRAY1 = LED_ARRAY1 & ~(1 << (i - 8));
                i++;
            } else if (i >= 16 && i < 24) {
                // Condition for right ON
                LED_ARRAY1 = (LED_ARRAY1 >> 1) | 0x80;
                i++;
            } else if (i >= 24 && i < 32) {
                // Condition for right OFF
                LED_ARRAY1 = LED_ARRAY1 << 1;
                i++;
            } else if (i >= 32) {
                i = 0;
            }
        } else if (key == SW2) {
            if (i < 8) {
                // Condition for left ON
                LED_ARRAY1 = (LED_ARRAY1 << 1) | 1;
                i++;
            } else if (i >= 8 && i < 16) {
                // Condition for left OFF
                LED_ARRAY1 = LED_ARRAY1 & ~(1 << (i - 8));
                i++;
            } else if (i >= 16) {
                i = 0;
            }
        } else if (key == SW3) 
        {
            if(flag)
            {
                LED_ARRAY1 = 0xAA;
            }
            else 
            {
                LED_ARRAY1 = ~LED_ARRAY1 ;   
            }
        } else if (key == SW4) 
        {
            // Code for pattern4
            // The LEDs have to blink nibble-wise, i.e., first 4 LEDs will be ON, next 4 LEDs will be OFF,
            // after that first 4 LEDs will be OFF, next 4 LEDs will be ON.
            if (flag) {
                LED_ARRAY1 = 0x0F; // First 4 LEDs ON, next 4 LEDs OFF
            } else {
                LED_ARRAY1 = 0xF0; // First 4 LEDs OFF, next 4 LEDs ON
            }
        }
        else
        {
            LED_ARRAY1 = OFF;
        }
    }
}