/*
 * File:   main.c
 * Author: Monica
 * Date:17.08.2024
 *
 * Created on 16 August, 2024, 7:12 PM
 */


#include <xc.h>
#include "Digital_keypad.h"
#include "ssd.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)


void init_config(void) 

{
    //Initializations here
    init_ssd();
    init_digital_keypad();
 
}
void main(void)
{
    unsigned char key;
    unsigned char digits[10] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char ssd[MAX_SSD_CNT];
    unsigned int delay = 0, count = 0;
    unsigned int flag = 0,delay1 = 0;
    init_config(); // Initialize hardware and configurations
   
    while(1)
    {
         key = read_digital_keypad(LEVEL);                                     
            
           
            if(key == SW2)
           {
            //write address 
            eeprom_write(0x03, (count % 10));
            eeprom_write(0x02, ((count % 100)/10));
            eeprom_write(0x01, ((count % 1000)/100));
            eeprom_write(0x00, (count / 1000));
            
           }
           else if(delay1++==100)
           {
                delay1 = 0;//reset the delay
            if(flag == 0)
            {
                //storing EEprom in count
             count = 1000*eeprom_read(0x00) + 100*eeprom_read(0x01) + 10*eeprom_read(0x02) + eeprom_read(0x03);
             flag = 1;
            }
           
              if (count > 9999) 
            {
                count = 0; //reset the count 
            }
                
           }
          else  if(key == SW1)
           {
               delay++;
               if(delay > 200)
               {
                   count=0;
               }
              
           }
          else if(delay < 200 && delay !=0)
              {
                count++;
                delay=0;
              }
      
             
        
           ssd[0]=digits[count/1000];
          ssd[1]=digits[(count/100)%10];
          ssd[2]=digits[(count/10)%10];
          ssd[3]=digits[(count%10)];
          display(ssd);
       
    }
    
}
