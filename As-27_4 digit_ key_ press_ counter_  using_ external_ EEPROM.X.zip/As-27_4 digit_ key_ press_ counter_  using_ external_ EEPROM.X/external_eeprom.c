#include "external_eeprom.h"
#include "i2c.h"
unsigned char external_eeprom_read(unsigned char addr)
{
    unsigned char data;
    
    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(addr);
    i2c_rep_start();
    i2c_write(SLAVE_READ_EE);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}

void external_eeprom_write(unsigned char addr, unsigned char data) // SEc_ADDR, data
{
    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(addr);
    i2c_write(data);
    i2c_stop();
}
