#ifndef EXTERNAL_EEPROM
#define	EXTERNAL_EEPROM

#define SLAVE_WRITE_EE             0xA0
#define SLAVE_READ_EE              0xA1



unsigned char external_eeprom_read(unsigned char addr);
void external_eeprom_write(unsigned char addr, unsigned char data);

#endif	/* DS1307_H */
