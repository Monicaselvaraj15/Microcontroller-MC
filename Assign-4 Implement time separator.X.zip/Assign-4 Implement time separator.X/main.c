/*
 * File:   main.c
 * Author: Monica
 * Date:15.08.24
 * Description:Implement the time seperator with timer0,timer1,timer2
 *
 * Created on 14 August, 2024, 9:13 PM
 */



#include <xc.h>
#include "main.h"
#include "timer.h"


#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)


static void init_config(void) {
    LED_ARRAY1 = 0x00;
    LED_ARRAY1_DDR = 0x00;
    
   
    init_timer0();     
    init_timer1();
    init_timer2();
    
    
  
    PEIE = 1;    // Enable peripheral interrupts
    GIE = 1; 
    
}

void main(void) {
    
    init_config();


    while (1)
    {
       ;
    }
    return;
}
