#include <xc.h>
#include "timer.h"
void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to Watchdog Timer */
    PSA = 1;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
}
void init_timer1(void)
{
    /* selecting the pre scale as 1:8 */
    T1CKPS1 = 1;
    T1CKPS0 = 1;
    
     TMR1H = 0XFE;              
     TMR1L = 0X0C;
     
     //timer1 interrpt enable
     TMR1IE=1;
     //timer1 interrupt clck source
     TMR1CS=0;
     //timer 1 turn on
     TMR1ON=1;
     
}
void init_timer2(void)
{
    T2CKPS1 = 1;
    T2CKPS0 = 1;
    /* Assinging the prescaler to Watchdog Timer */
     PR2=250;
     /* The timer interrupt is enabled */
      TMR2IE = 1;
      //timer 2 turn on
     TMR2ON=1;
}