#ifndef MAIN_H
#define	MAIN_H

void key_on_press(unsigned char key);

#endif	/* MAIN_H */