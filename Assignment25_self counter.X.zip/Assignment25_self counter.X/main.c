/*
 * File:   main.c
 * Author: Monica
 Date:15.08.24
 *
 * Created on 15 August, 2024, 9:27 PM
 */


#include <xc.h>
#include "main.h"
#include "ssd.h"
#include "Digital_keypad.h"


#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 

{
    //Initializations here
    init_ssd();
    init_digital_keypad();
 
}

void main(void)
{
    init_config();
    static unsigned char ssd[MAX_SSD_CNT]={ZERO,ZERO,ZERO,ZERO};
    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
	static unsigned  int count = 0, flag = 0, delay = 0;
	unsigned char key ;
	while(1)
	{
        
        key = read_digital_keypad(STATE);
        
        if (key == SW2)
        {
            //write address 
            eeprom_write(0x03, (count % 10));
            eeprom_write(0x02, ((count % 100)/10));
            eeprom_write(0x01, ((count % 1000)/100));
            eeprom_write(0x00, (count / 1000));
        }
        
        if(delay++ == 500)
        {
            delay = 0;//reset the delay
            if(flag == 0)
            {
                //storing EEprom in count
             count = 1000*eeprom_read(0x00) + 100*eeprom_read(0x01) + 10*eeprom_read(0x02) + eeprom_read(0x03);
             flag = 1;
            }
            else
            {
                count++; //incrementing count value
            }
            if (count > 9999) 
            {
                count = 0; //reset the count 
            }
            ssd[3] = digit[count % 10]; //unit 4
            ssd[2] = digit[(count % 100)/10]; //ten place 34
            ssd[1] = digit[(count % 1000)/100];//hundred  place 234
            ssd[0] = digit[count / 1000];//thousand 1234
        }        
        /*giving digit to ssd */       
        display(ssd);
	}

}