/*
 * File:   main.c
 * Author: Monica
 * Date:28.08.24
 *
 * Created on 26 August, 2024, 10:14 PM
 */


#include <xc.h>
#include "clcd.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 
{
    //Initializations here 
    init_clcd();
    init_digital_keypad();
}

void main(void) 
{
 unsigned char key = 0;
unsigned char arr[] = "0000000000";
unsigned int oper_flag = 1, delay = 0, blink_state = 1, pos = 9,index = 9;;

init_config();
while (1) 
{
    // Display header
    clcd_print("var.Down Counter", LINE1(0));
    clcd_print("Count:", LINE2(0));

    key = read_digital_keypad(STATE);

    if (key == SW3) 
    {
        oper_flag = !oper_flag;  // Toggle between edit and run mode
    }

    if (oper_flag) // Edit mode
    {     
        if (delay++ >= 5)
        {
            delay = 0;
            blink_state = !blink_state;  // Toggle blink state
        }

       
        clcd_print(arr, LINE2(6));

        
        if (blink_state)
        {
            clcd_putch(arr[pos], LINE2(6 + pos));  
        }
        else
        {
            clcd_putch(' ', LINE2(6 + pos));  
        }

        if (key == SW1)
        {
            arr[pos]++;
            if (arr[pos] == ':')  
            {
                arr[pos] = '0';
            }
        }
        else if (key == SW2)
        {
            pos--;  
            if (pos < 0)
            {
                pos = 9;  
            }
        }
    }
    else // Run mode
    {
       
        int all_zero = 1;
        for (int i = 0; i <= 9; i++)
        {
            if (arr[i] != '0')
            {
                all_zero = 0;
                break;
            }
        }

        if (!all_zero)
        {
           
            int index = 9;
            arr[index]--;

         
            while (arr[index] == '/' && index >= 0)
            {
                arr[index] = '9';  
                index--;  
                if (index >= 0)
                {
                    arr[index]--;  
                }
            }

            clcd_print(arr, LINE2(6));  
        }
    }
}
}