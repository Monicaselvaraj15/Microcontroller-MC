/*
 * File:   main.c
 * Author: Monica
 * Date:30.08.24
 *
 * Created on 30 August, 2024, 10:38 AM
 */


#include <xc.h>
#include "adc.h"
#include "ssd.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) {
    //Initializations here 
    init_ssd();
    init_adc();
}

void main(void) 
{
   unsigned int delay=0,count=9999;
  static unsigned char ssd[MAX_SSD_CNT]={NINE,NINE,NINE,NINE};
  static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
  unsigned short adc_reg_val, pot_value=1023;
    init_config();
    while (1) 
   {
        //Application code here 
        adc_reg_val = read_adc();//10 bits -> 0 to 1023
         pot_value = adc_reg_val;  //update the value
        if(delay++>=(1023-pot_value))
        {
            delay=0;
            if(count > 0)
            {    
              count--;
            } 
        }
 
            ssd[3] = digit[count % 10]; //unit 4
            ssd[2] = digit[(count % 100)/10]; //ten place 34
            ssd[1] = digit[(count % 1000)/100];//hundred  place 234
            ssd[0] = digit[count / 1000];//thousand 1234
            display(ssd);
    
       
    }

}
