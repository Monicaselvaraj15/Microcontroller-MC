/*
 * File:   main.c
 * Author: Monica
 * Date:02.09.24
 *
 * Created on 2 September, 2024, 6:46 PM
 */


#include <xc.h>
#include "adc.h"
#include "main.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)
#define PERIOD 1024  // Set PERIOD to match the ADC max value (1024)

void software_pwm(unsigned short adc_reg_val) 
{
    static unsigned int loop_counter = 0;
    unsigned int duty_cycle;
    // PWM logic
    if (adc_reg_val <= 512) 
    {
        duty_cycle = adc_reg_val; 
    } else if(adc_reg_val <=1024)
    {
        duty_cycle=adc_reg_val;
    }
    
    if(loop_counter < duty_cycle)
    {
        LED0=1;
        
    }
    else
    {
        LED0=0;
    }

    if (++loop_counter >= PERIOD) 
            
    {
        loop_counter = 0;
    }
}

void init_config(void) {
    // Initializations here 
    LED_ARRAY1 = OFF;
    LED_ARRAY1_DDR = 0x00;
    init_adc();
}

void main(void) {
    unsigned short adc_reg_val;

    init_config();

    while (1) {
        // Read ADC value
        adc_reg_val = read_adc();
        software_pwm(adc_reg_val);
    }
}