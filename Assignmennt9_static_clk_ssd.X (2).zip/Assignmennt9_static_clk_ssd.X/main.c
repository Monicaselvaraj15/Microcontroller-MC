/*
 * File:   main.c
 * Author: Monica
 *Date:08/08/24
 * Created on 8 August, 2024, 10:34 AM
 */


#include <xc.h>
#include "ssd.h"
#include "tiimer.h"
#include "main.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 
{
    //Initializations here 
    init_ssd();
    init_timer0();
    /* Enable all the Global Interrupts */
    GIE = 1;
    
}
extern int hr = 12, min = 0, sec = 0;
unsigned int flag = 1;
//unsigned int dp_blink_flag = 0;  // New flag for DP blinking

void __interrupt() isr(void)
{
    static unsigned int count = 0;
//    static unsigned int dp_count = 0;  // Counter for DP blinking

    if (TMR0IF == 1)
    {
        TMR0 = TMR0 + 8;

        if (++count == 10000)
        {
            flag = !flag;
        }
        else if(count == 20000)
        {
            count = 0;
            min++;
            if(min == 60)
            {
                hr++;
                min = 0;
                if(hr == 24)
                {
                    hr = 0;
                }
            }
        }
      


         TMR0IF = 0;
    }
}

void main(void) 
{
    unsigned char digits[10] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char ssd[MAX_SSD_CNT];
    unsigned int flag=1,delay=0;
    unsigned int dp_flag=0;
    init_config();
    while (1) 
    {
        //Application code here
        if (++delay >= 200) // Adjust the value for desired blink rate
        {
            dp_flag = !dp_flag;
            delay = 0; // Reset the dp_delay counter
        }
         if(flag==1)
        {
                 ssd[0] = digits[hr/10];    //1    
                 ssd[1] = (digits[hr%10] | (dp_flag ? DOT : 0));  //2
                 ssd[2] = digits[min/10];     // 0
                 ssd[3] = digits[min%10];  // 0
           //next time after 60 min hr will be increment then 13.00 starts
             
        }
        else
        {
            
            ssd[0] = digits[hr/10];        
            ssd[1] = digits[hr%10];  
            ssd[2] = digits[min/10];     
            ssd[3] = digits[min%10];  
        }
        display(ssd);
        
        }
       
    }
