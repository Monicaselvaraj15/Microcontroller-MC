/* 
 * File:   main.h
 */

#ifndef MAIN_H
#define	MAIN_H

void init_timer0(void);
#endif	/* MAIN_H */