#include <xc.h>
#include "main.h"
extern int hr=12,min=0,flag=0;
void __interrupt() isr(void)
{
    static unsigned int count = 0;
    
    if (TMR0IF == 1)
    {
        /* TMR0 Register valur + 6 (offset count to get 250 ticks) + 2 Inst Cycle */
        TMR0 = TMR0 + 8;
        
        if (++count == 10000)
        {
            flag=!flag;
            
        }
        else if(++count==20000)
        {
            count=0;
            min++;
            if(min==60)
            {
                hr++;
                min=0;
                if(hr==24)
                {
                    hr=0;
                }
            }
        }
       
        
        TMR0IF = 0;
    }
}
