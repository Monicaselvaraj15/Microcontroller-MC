#include <xc.h>
void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to Timer0 */
    PSA = 0;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
    TMR0IE = 1;
}