/*
 * File:   main.c
 * Author: Monica
 * Date :09.09.24
 *
 * Created on 9 September, 2024, 3:04 PM
 */


#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include "main.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)


void display(unsigned short adc_reg_val)
{ 
    char arr[5];
    int i;

    i = 1; // buff: "1 0 2 3"
    do
    {               
     
        arr[i] = (adc_reg_val % 10) + '0';//10%10 -> 0 + '0' 
        /*convert mv to celcious*/
        adc_reg_val = adc_reg_val / 10; //0
    } while (i--); // 0
    arr[2] = '.';
    arr[3] = 'C';
    arr[4] = '\0';
    /*display the result  in clcd*/
    clcd_print("TEMP :",LINE2(0));
    clcd_print(arr, LINE2(7));
}

static void init_config(void) 
{
    init_clcd();
    init_adc();
    
    clcd_print("ROOM TEMPERATURE", LINE1(0));
}

void main(void) 
{
    unsigned short int adc_reg_val,x;
    
    init_config();

    while (1) {
        adc_reg_val = read_adc(CHANNEL2); 

        
        x = ((double)adc_reg_val * 0.488);
        display(x);
    }
    return;
}

