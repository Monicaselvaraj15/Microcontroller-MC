#include <xc.h>
#include <string.h>
#include "timer.h"
unsigned char count=0,change=0;

void __interrupt() isr(void)
{
    if (TMR0IF)  // Check if Timer0 interrupt flag is set
    {

        TMR0 = 6;  

        // Increment count and toggle flag every 500 ms
        if (++count >= 20000)  // Adjust 20000 as needed
        {
            count = 0;
            change++; // Toggle the flag state
        }

        TMR0IF = 0;  // Clear Timer0 interrupt flag
    }
}