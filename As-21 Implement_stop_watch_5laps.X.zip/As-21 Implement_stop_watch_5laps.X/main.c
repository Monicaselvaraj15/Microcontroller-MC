/*
 * File:   main.c
 * Author: Monica
 * Date:10.09.24
 *
 * Created on 6 September, 2024, 9:48 PM
 */


#include <xc.h>
#include <string.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "timer.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

extern int change;
static void clcd_write(unsigned char byte, unsigned char mode)
{
    CLCD_RS = mode;
    
    CLCD_DATA_PORT = byte & 0xF0;
    CLCD_EN = HI;
    __delay_us(100);
    CLCD_EN = LOW;

    CLCD_DATA_PORT = (byte & 0x0F) << 4;
    CLCD_EN = HI;
    __delay_us(100);
    CLCD_EN = LOW;
    
    __delay_us(4100);
}
/* function to initialize matrix keypad and clcd */
static void init_config(void)
{
	init_matrix_keypad();
	init_clcd();
    init_timer0();
          
    GIE = 1;
    
}
void main(void)
{
  
    char rec[] = "00:00:00:00", rec1[12],rec2[12],rec3[12],rec4[12],rec5[12];
    long int count = -1, once, count1 = -1;
    unsigned int delay;
    init_config();                      
    clcd_print("Stop watch ",LINE1(3)); 
    clcd_print("Press start key",LINE2(0));
    unsigned char key;
    short int flag = 0;
    while(1)
    {
        key = read_matrix_keypad(STATE);
        if(key == 1)
        {    
            clear_screen();
            flag = !flag;           
            TMR0IE = !TMR0IE;
            if(once == 1)
            {
                TMR0IE = 1;
                once = 0;
            }         
            clcd_print("Record          ",LINE1(0));

        }
        if(key == 2)
        {
           
            count = (count  + 1) % 5;
            switch(count)
            {
                case 0: 
                    strcpy(rec1, rec);                            
                    clcd_print("L0 : ",LINE2(0));
                    clcd_print(rec1,LINE2(5)); 
                    break;
                case 1:
                    strcpy(rec2, rec);
                    clcd_print("L1 : ",LINE2(0));
                    clcd_print(rec2,LINE2(5));

                    break;
                case 2:
                    strcpy(rec3, rec);                      
                    clcd_print("L2 : ",LINE2(0));
                    clcd_print(rec3,LINE2(5));
                    break;
                case 3:
                    strcpy(rec4, rec);                        
                    clcd_print("L3 : ",LINE2(0));
                    clcd_print(rec4,LINE2(5));
                    break;
                case 4:
                    strcpy(rec5, rec);
                    clcd_print("L4 : ",LINE2(0));
                    clcd_print(rec5,LINE2(5));                 
                    break;       
            }
            
        }
        if(key == 2 && flag == 0)
        {
            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            strcpy(rec,"00:00:00:00");
            clcd_print(rec,LINE1(0));
            strcpy(rec,"");
            strcpy(rec,"");
            strcpy(rec3,"");
            strcpy(rec4,"");
            strcpy(rec5,"");
        }
        if(key == 3 || key == 4)
        {
         
            if(key == 3)
            {
                count1 =(count1 + 1) % 5;
            }
            else
            {
                count1 = (count1 - 1) % 5;
            }
            if(count1 < 0)
            {
                count1 = 4;
            }
            else if(count1 > 4)
            {
                count1 = 0;
            }
            switch(count1)
            {
                case 0: 
                    clcd_print("L0 : ",LINE2(0));
                    clcd_print(rec2,LINE2(5));
                    break;
                case 1:
                    clcd_print("L1 : ",LINE2(0));
                    clcd_print(rec3,LINE2(5));
                    break;
                case 2:
                    clcd_print("L2 : ",LINE2(0)); 
                    clcd_print(rec4,LINE2(5));
                    break;
                case 3:
                    clcd_print("L3 : ",LINE2(0));
                    clcd_print(rec5,LINE2(5));
                    break;
                case 4:
                    clcd_print("L4 : ",LINE2(0));
                    clcd_print(rec1,LINE2(5));
                    break;       
            }

        } 
        if(flag == 1)
        {
             rec[10] = rec[10] + 1;
            if(rec[10]++ == '9' )
            {
                rec[10] = '0';
                rec[9] = rec[9] - 1;       
            }
            if(rec[9]++ == '6' )
            {
                rec[9] = '0';
                  rec[7] =rec[7] + 1; 
            }                                                                                     
            if(rec[7] > '9')                                  
            {                    
                rec[7] = '0';                            
                rec[6] = rec[6] + 1;                                     
            }                                     
            if(rec[6] > '5')                                    
            {                           
                rec[6] = '0';                           
                rec[4] = rec[4] + 1;                                    
            }  
            if(rec[4] > '9')                      
            {                         
                rec[4] = '0';                        
                rec[3] = rec[3] + 1;                     
            }                     
            if(rec[3] > '5')                      
            {                           
                rec[3] = '0';                         
                rec[1] = rec[1] + 1;                      
            }                     
            if(rec[1] > '9')                       
            {                            
                rec[1] = '0';                          
                rec[0] = rec[0] + 1;                       
            }                        
            if(rec[0] > '5')                     
            {                           
                rec[0] = 0;                    
            }                           
            clcd_print("SW : ",LINE1(0));
            clcd_print(rec,LINE1(5));    
        }                                                                     

    }

}


