/*
 * File:   main.c
 * Author: Monic
 *Date:19.08.24
 * Created on 19 August, 2024, 3:18 PM
 */


#include <xc.h>
#include "clcd.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) {
    //Initializations here 
    init_clcd();
}

void main(void) {
    init_config();
   
   unsigned char temp;
    unsigned int delay=0;
    char arr1[]="Have_a_nice_day!";
    while (1) {
        //Application code here 
        clcd_print("Right scrolling",LINE1(0));
        temp=arr1[15];
        for(int i = 15 ; i > 0 ; i--)
        {
            arr1[i]=arr1[i-1];
           
        }
        arr1[0]=temp;
        clcd_print(arr1,LINE2(0));
        if(delay++==50000)
        {
            delay=0;
        }
        
    }
    return ;
}
