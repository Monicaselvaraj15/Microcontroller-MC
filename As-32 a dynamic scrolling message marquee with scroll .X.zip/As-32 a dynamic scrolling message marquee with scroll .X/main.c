/*
 * File:   main.c
 * Author: Monica
 * Date:13.09.24
 *
 * Created on 10 September, 2024, 12:50 PM
 */

#include <xc.h>
#include <string.h>
#include "clcd.h"
#include "digital_keypad.h"
#include "timer.h"
#include "uart.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 
{
    // Initializations here 
    init_clcd();
    init_digital_keypad();
    init_timer0();
    init_uart(9600);
     puts("UART Test Code\n\r");
    PEIE = 1;
    GIE = 1;
}

char uart_receive_char() 
{
    unsigned ch;
     if (RCIF == 1)
    {
        if (OERR == 1)
            OERR = 0;
        
        ch = RCREG;
        
        RCIF = 0;
    } 
}

void main(void) {
    unsigned char marquee_flag = 1, s_flag = 1, received_data, received_once = 0,scroll=1;
    char arr1[] = "0123456789"; 
    unsigned char key = 0;
    unsigned int temp;
    char message_buffer[32];  // Buffer to store the new message
    int msg_index = 0;        // To keep track of input message length

    init_config();
   
    while (1) {
        key = read_digital_keypad(STATE);  // Read the keypad state
        
        // Display the scrolling message if s_flag is set
        if (s_flag) 
        {    
            clcd_print("msg display", LINE1(0));
            
            if (marquee_flag == 1) 
            {
                temp = arr1[0];
                for (int i = 0; i < 9; i++) 
                {
                    arr1[i] = arr1[i + 1];
                }
                arr1[9] = temp;
                clcd_print(arr1, LINE2(0));
                
            } else if (marquee_flag == 0) 
            {
                temp = arr1[9];
                for (int i = 9; i > 0; i--) 
                {
                    arr1[i] = arr1[i - 1];
                }
                arr1[0] = temp;
                clcd_print(arr1, LINE2(0));
              
            }
            
            // Control marquee scrolling with switches
            if (key == SW1) 
            {
                marquee_flag = 1;  
            } else if (key == SW2) 
            {
                marquee_flag = 0;  
            }
        }
       
        if (key == SW3) 
        {
            s_flag = !s_flag;
        }

        // Check for UART input
         
        received_data = uart_receive_char();  // Receive data from UART
         
        if (received_data == '#') 
        {
            s_flag=0;
            clear_screen(CLEAR_DISP_SCREEN, INST_MODE);  
            clcd_print("enter new msg", LINE1(0));  
            clcd_print("msg:", LINE2(0));
            received_once = 1;  // Set flag indicating message input mode
//            msg_index = 0;  // Reset message  index
        }

        // Handle new message input
        if (received_once == 1) 
        {
              received_data = uart_receive_char();  // Keep receiving data
            
            if (received_data != '#') 
            {
                if (msg_index < 11) 
                {  
                    message_buffer[msg_index++] = received_data;  // Store the character
                    clcd_write_char(received_data);  // Display the character
                }
            }   
            else 
            {
                // When '#' is received again, end message input
                message_buffer[msg_index] = '\0';  // Null-terminate the message
                clear_screen(CLEAR_DISP_SCREEN, INST_MODE); 
                clcd_print("Message display", LINE1(0));  // Indicate message saved
                clcd_print(message_buffer, LINE2(0));  
                received_once = 0;  // Reset flag, exit message input mode
            }
        }
    }
    

}