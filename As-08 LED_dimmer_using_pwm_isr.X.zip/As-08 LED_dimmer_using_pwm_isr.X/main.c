/*
 * File:   main.c
 * Author: Monica
 * Date:04.09.24
 *
 * Created on 4 September, 2024, 6:55 PM
 */

#include <xc.h>
#include "adc.h"
#include "main.h"
#include "timer.h"

#pragma config WDTE = OFF 

unsigned short adc_reg_val;  

void init_config(void) {
    // Initializations here 
    LED_ARRAY1 = OFF;            
    LED_ARRAY1_DDR = 0x00;       
    init_adc();                 
    init_timer0();     
    TMR0 = 0;
    TMR0IE = 1; 
    GIE = 1; 
    PEIE = 1; 
}

void main(void) 
{
    init_config(); 

    while (1) 
    {
        // Read ADC value
        adc_reg_val = read_adc();
       
    }
}