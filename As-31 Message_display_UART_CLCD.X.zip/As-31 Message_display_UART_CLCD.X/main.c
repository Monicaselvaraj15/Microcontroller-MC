/*
 * File:   main.c
 * Author: Monica
 * Date:11.09.24
 *
 * Created on 2 September, 2024, 11:36 AM
 */


#include <xc.h>
#include <string.h>
#include "clcd.h"
#include "uart.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

#define BUFFER_SIZE 32

 unsigned char ch;

void init_config(void) {
    // Initialize CLCD and UART
    init_clcd();
    init_uart(9600);
    
    puts("UART Test Code\n\r");
    
    // Enable peripheral interrupt
    PEIE = 1;
    
    // Enable global interrupt
    GIE = 1;
}

void main(void) {
    // Initialize configuration
    init_config();

    // Buffers for holding the characters
    unsigned char arr[2][16] = { {' '}, {' '} };
    unsigned int i = 0;  // Use unsigned int to avoid negative values

    while (1) {
        // Read character from serial terminal
        if (ch != '\0') 
        {
            putchar(ch);  // Echo the character

            // Place character into appropriate buffer
            if (i < 16) 
            {
                arr[0][i] = ch;
            } 
            else if (i < BUFFER_SIZE) 
            {
                arr[1][i - 16] = ch;
            }

            // Increment index
            i++;

            // Check if index has exceeded buffer size
            if (i >= BUFFER_SIZE) 
            {
                // Clear arr[0] by filling it with spaces
                for (int j = 0; j < 16; j++) 
                {
                    arr[0][j] = ' ';
                }
                
                // Copy arr[1] to arr[0]
                for (int j = 0; j < 16; j++)
                {
                    arr[0][j] = arr[1][j];
                }
                
                // Clear arr[1]
                for (int j = 0; j < 16; j++)
                {
                    arr[1][j] = ' ';
                }
                
                // Add new character to arr[1]
                arr[1][0] = ch;
                i = 16;
                
                
            }

            // Clear the character from the input to prevent reprocessing
            ch = '\0';

            // Update the CLCD with new buffer contents
            clear_screen(CLEAR_DISP_SCREEN, INST_MODE); // Clear the LCD screen
            clcd_print(arr[0], LINE1(0)); // Display the first line
            clcd_print(arr[1], LINE2(0)); // Display the second line
        }
    }
}