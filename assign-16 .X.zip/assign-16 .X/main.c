/*
 * File:   main.c
 * Author: Monica
 * Date:20.08.2024
 *
 * Created on 19 August, 2024, 9:16 PM
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        /* Watchdog Timer Enable bit (WDT disabled)*/

static void init_config(void) {
    /*initialization of keypad and ssd*/
    init_ssd();
    init_digital_keypad();
}

void main(void) 
{
    /*initialization of keypad and ssd values*/
 init_config();
unsigned char ssd[MAX_SSD_CNT];
unsigned int digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, UNDERSCORE, UNDERSCORE};
unsigned char key = 0, last_key = ALL_RELEASED;
unsigned int count = 0, marquee_flag = 1, oper_flag = 1, marquee_delay = 0, i = 0;

while (1)
{
    
        key = read_digital_keypad(STATE);

        if (key != last_key) // Key state has changed
        {
            last_key = key; // Update the last key state
            if (key != ALL_RELEASED) 
            {
                if (key == SW1)
                {
                    marquee_flag = 1;  // Left marquee
                }
                else if (key == SW2)
                {
                    marquee_flag = 0;  // Right marquee
                }
                else if (key == SW3)
                {
                    oper_flag = !oper_flag;  // Toggle operation flag
                }
            }
        }

        // Marquee handling with separate delay
        if (marquee_delay++ == 200)
        {
            marquee_delay = 0;

            if (oper_flag)  // Operate based on the current mode
            {
                // Left marquee
                if (marquee_flag == 1)
                {
                    i++;
                    if (count++ >= 11)
                    {
                        count = 0;
                        i = 0;
                    }
                }
                // Right marquee
                else
                {
                    i--;
                    if (count-- <= 0)
                    {
                        count = 11;
                        i = 11;
                    }
                }
            }
        }

        // Update SSD display
        ssd[0] = digit[i % 12];
        ssd[1] = digit[(i + 1) % 12];
        ssd[2] = digit[(i + 2) % 12];
        ssd[3] = digit[(i + 3) % 12];
        display(ssd);
        }
}    