/*
 * File:   main.c
 * Author: Monica
 *Date:16.09.24
 * Created on 3 September, 2024, 11:50 AM
 */


#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 
{
    //Initializations here 
     init_i2c(100000);
     
    init_clcd();
    
    init_digital_keypad();
    
    init_adc();
    
    init_ds1307();
    
    init_timer2();
    init_uart(9600);
   
    puts("***car event***\n\r");
    
    GIE=1;
    PEIE=1;
    
   
}



void main(void) 
{
 init_config();
    unsigned short adc_reg_val;
    char event[3]="ON";
    unsigned char speed=0;
    unsigned char control_flag=DASH_BOARD,reset_flag,menu_pos;
    unsigned char key=0;
    char *gear[]={"GN","GR","GR1","GR2","GR3","GR4"};
     log_event((char *)event, speed); 
    unsigned char gr=0;
    eeprom_str_write(0x00,"1010");
    
    
    while (1) 
    {
        //Application code here 
        speed = (unsigned char) (read_adc() / 10); // 0 to 1024
        
            if(speed > 99)
            {
                speed=99;
            }
       
            key=read_digital_keypad(STATE);
            
            
            for(int i=300;i--;);
            
            if(key==SW1)
            {
                strcpy(event,"C ");
                log_event(event,speed);
            }
            else if (key== SW2 && gr <= 5)
            {
                strcpy(event,gear[gr]);
                gr++;
                log_event(event,speed);
            }
            else if(key==SW3 && gr > 0)
            {
                gr--;
                strcpy(event,gear[gr]);
                log_event(event,speed);
            }
            else if((control_flag==DASH_BOARD) && ( key==SW4 || key==SW5))
            {
                control_flag=LOGIN_SCREEN;
                clear_screen();
                clcd_print("Enter password",LINE1(1));
                clcd_putch(' ',LINE2(5));
                clcd_write(DISP_ON_AND_CURSOR_ON ,INST_MODE);
                __delay_us(1000);
                reset_flag=RESET_PASSWORD;
                TMR2ON=1;
            }
            else if (key == SW4 && control_flag == LOGIN_MENU_FLAG)
        {
            switch (menu_pos)
            {
                case 0: /* View Log */

                    clear_screen();
                    clcd_print("      Logs      ", LINE1(0));
                    control_flag = VIEW_LOG_FLAG;
                    reset_flag = RESET_VIEW_LOG_POS;
                    break;

                case 1: /* Clear Log */

                    clear_screen();
                    control_flag = CLEAR_LOG_FLAG;
                    reset_flag = RESET_MEMORY;
                    break;

                case 2: /* Download Log */

                    clear_screen();
                    log_event("DL", speed);
                    clcd_print("      Open      ", LINE1(0));
                    clcd_print("     Cutecom    ", LINE2(0));
                    download_log();
                    __delay_ms(2000);
                    control_flag = LOGIN_MENU_FLAG;
                    reset_flag = RESET_LOGIN_MENU;
                    break;

                case 3: /* Change Password */

                    clear_screen();
                    control_flag = CHANGE_PASSWORD_FLAG;
                    reset_flag = RESET_PASSWORD;
                    TMR2ON = 1;
                    break;

                case 4: /* Set Time */

                    clear_screen();
                    log_event("ST", speed);
                    control_flag = SET_TIME_FLAG;
                    reset_flag = RESET_TIME;
                    break;
            }
        }

        else if (key == SW4_LP && control_flag == VIEW_LOG_FLAG)
        {
            control_flag = LOGIN_MENU_FLAG;
            clear_screen();
        }
         else if (key == SW4_LP && control_flag == CHANGE_PASSWORD_FLAG)
        {
            control_flag = LOGIN_MENU_FLAG;
            clear_screen();
        }

        else if (key == SW5_LP && control_flag == LOGIN_MENU_FLAG)
        {
            control_flag = DASH_BOARD;
            clear_screen();
        }
             
     
                 switch(control_flag)
               {        
                        case DASH_BOARD :
                            display_dashboard(event,speed);
                            break;
                        case LOGIN_SCREEN :
                            switch(login(key,reset_flag))
                            {
                                 case RETURN_BACK :
                                    control_flag=DASH_BOARD;
                                    TMR2ON=0;
                                    clcd_write(DISP_ON_AND_CURSOR_OFF ,INST_MODE);
                                    __delay_us(50000);
                                    clear_screen();
                                    break;
                                 case LOGIN_SUCCESS :
                                    control_flag=LOGIN_MENU_FLAG;
                                     TMR2ON=0;
                                    clcd_write(DISP_ON_AND_CURSOR_OFF ,INST_MODE);
                                    __delay_us(50000);
                                    reset_flag=RESET_LOGIN_MENU;
                                    continue;
                        
                            }
                            break;
                          case LOGIN_MENU_FLAG:

                                switch (display_menu(key, reset_flag))
                                {
                                    case RETURN_BACK: 
                                        clear_screen();
                                        control_flag = DASH_BOARD; 
                                        TMR2ON = 0; 
                                        break;

                                    case 0: 
                                        menu_pos = 0;
                                        break;

                                    case 1: 
                                        menu_pos = 1;
                                        break;

                                    case 2:
                                        menu_pos = 2;
                                        break;

                                    case 3 : 
                                        menu_pos = 3;
                                        break;

                                    case 4: 
                                        menu_pos = 4;
                                        break;
                                }
                                break;

                               case VIEW_LOG_FLAG: /* View Log */

                                view_log(key, reset_flag); 
                                break;

                                case CLEAR_LOG_FLAG: /* Clear Log */

                                    if (clear_log(reset_flag) == TASK_SUCCESS)
                                        __delay_ms(1000);

                                    if (reset_flag == RESET_MEMORY)
                                        log_event("CL", speed);

                                    control_flag = LOGIN_MENU_FLAG; 
                                    reset_flag = RESET_LOGIN_MENU;
                                    clear_screen();
                                    break;

                                   case CHANGE_PASSWORD_FLAG: /* Change Password */

                                        switch (change_password(key, reset_flag))
                                        {
                                            case TASK_SUCCESS:
                                                __delay_ms(1000);
                                                log_event("CP", speed);
                                                control_flag = LOGIN_MENU_FLAG; 
                                                reset_flag = RESET_LOGIN_MENU;
                                                clear_screen();
                                                break;

                                         case RETURN_BACK:
                                                control_flag = DASH_BOARD; /* go back to dashboard */
                                                reset_flag = RESET_LOGIN_MENU;
                                                break;
                                        }
                                        break;

                                        case SET_TIME_FLAG: /* Set Time */

                                            if (change_time(key, reset_flag) == TASK_SUCCESS)
                                            {
                                                control_flag = LOGIN_MENU_FLAG; 
                                                reset_flag = RESET_LOGIN_MENU;
                                                clear_screen();
                                                continue;
                                            }
                                                break;

                        }
                                reset_flag=RESET_NOTHING;
}
    return ;
}
