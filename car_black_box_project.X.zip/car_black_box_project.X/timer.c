#include "main.h"

void init_timer2(void)
{
    T2CKPS1 = 1;
    T2CKPS0 = 1;
    /* Assinging the prescaler to Watchdog Timer */
     PR2=250;
     /* The timer interrupt is enabled */
      TMR2IE = 1;
      //timer 2 turn on
     TMR2ON=0;
}