#include "main.h"


#define SLAVE_WRITE_EE             0xA0
#define SLAVE_READ_EE              0xA1



unsigned char external_eeprom_read(unsigned char memory_loc);
void external_eeprom_write(unsigned char memory_loc, unsigned char data);
void eeprom_str_write(unsigned char memory_loc, char *data);
