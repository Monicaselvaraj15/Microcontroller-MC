#include "main.h"
#include "external_eeprom.h"
#include "i2c.h"

unsigned char external_eeprom_read(unsigned char memory_loc)
{
    unsigned char data;
    
    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(memory_loc);
    i2c_rep_start();
    i2c_write(SLAVE_READ_EE);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}

void external_eeprom_write(unsigned char memory_loc, unsigned char data) // SEc_ADDR, data
{
    i2c_start();
    i2c_write(SLAVE_WRITE_EE);
    i2c_write(memory_loc);
    i2c_write(data);
    i2c_stop();
}
void eeprom_str_write(unsigned char memory_loc,char *data)
{
    while(*data!=0)
    {
        external_eeprom_write( memory_loc, *data);
        data++;
        memory_loc++;
    }
}