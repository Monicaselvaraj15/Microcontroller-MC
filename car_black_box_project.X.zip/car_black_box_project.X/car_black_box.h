#ifndef CAR_BLACK_BOX_H
#define CAR_BLACK_BOX_H

void display_dashboard(unsigned char event[],unsigned char speed);
void log_event(unsigned char event[],unsigned char speed);
void store_log_event(void);
void clear_screen(void);
unsigned char login(unsigned char key,unsigned char reset_flag);
unsigned char display_menu(unsigned char key,unsigned char reset_flag);
void view_log(unsigned char key, char reset_index);
char clear_log(unsigned char reset_flag);
void download_log(void);
char change_password(unsigned char key, char reset_pwd );
char change_time(unsigned char key, unsigned char reset_time);
#endif