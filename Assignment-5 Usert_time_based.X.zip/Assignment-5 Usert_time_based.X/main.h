#ifndef MAIN_H
#define	MAIN_H

#define LED1                RD0

#define LED_ARRAY1          PORTD
#define LED_ARRAY1_DDR      TRISD

#define ON                  1
#define OFF                 0

#endif	/* MAIN_H */
