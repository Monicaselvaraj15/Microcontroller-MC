#include <xc.h>
#include "main.h"

unsigned long int period = 100,duty_cycle=50,count=0;
void __interrupt() isr(void)
{        
    if (TMR0IF == 1)
    {
        /*50 percentage LED Blinking*/
        if(count < duty_cycle )
        {
            LED1 = 1;
        }
        if(count >= duty_cycle && count < period)
        {
            LED1 = 0;
        }
        if(count++ == period)
        {
            count = 0;
        }
        
        TMR0IF = 0;
    }
    

}