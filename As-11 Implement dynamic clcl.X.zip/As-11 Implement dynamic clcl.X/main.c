/*
 * File:   main.c
 * Author: Monica
 * Date:31.08.24
 *
 * Created on 12 August, 2024, 7:45 PM
 */

#include <xc.h>
#include "main.h"
#include "ssd.h"
#include "digital_keypad.h"
#include "timer.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)
void init_config(void) 
{
    // Initializations here 
    init_ssd();
    init_timer0();
    init_timer2();
    init_digital_keypad();
    /* Enable all the Global Interrupts */
    PEIE = 1; // Enable peripheral interrupt
    GIE = 1;  // Enable global interrupt
}

void main(void)
{
    unsigned char digits[10]={ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE};
    unsigned char ssd[MAX_SSD_CNT]={ZERO,ZERO,ZERO,ZERO};  
    unsigned int hr = 0, min = 0, sec = 0,  delay = 0;
    unsigned char key = 0;
    unsigned int oper_flag = 1, min_fflag = 1,dp_flag=0,blink_flag=0,hr_fflag=1,feild_flag=0;
    init_config();

    while (1) 
    {
        key = read_digital_keypad(STATE);  
        if (oper_flag==1)   // Run mode
        {   
            if (++delay >= 200) // Adjust the value for desired blink rate
            {
                dp_flag = !dp_flag;
                delay = 0; // Reset the dp_delay counter
            } 
            if(key==SW4)
            {
            //turn off the timer
                TMR0=0;
                oper_flag=0;
            }
        ssd[0] = digits[hr/10] ;    //0   
        ssd[1] =(digits[hr%10]| (dp_flag ? DOT : 0)); //0
        ssd[2] = digits[min/10]; 
        ssd[3] = digits[min%10]; 
        display(ssd);  
        }
        else
        {
            // Edit mode
            if(++delay<=200)
            {
                ssd[0] =(feild_flag==1 ? 0 : digits[hr/10]) ; //0    
                ssd[1] =(feild_flag==1 ? 0 : digits[hr%10]); //0
                ssd[2] =(feild_flag==0 ? 0 : digits[min/10])  ; 
                ssd[3] =(feild_flag==0 ? 0 : digits[min%10]) ; 
                display(ssd);   
            }
            else if(delay>200 && delay<400)
            {
                ssd[0] = digits[hr/10];    //0    
                ssd[1] = digits[hr%10]; //0
                ssd[2] = digits[min/10]; 
                ssd[3] = digits[min%10]; 
                display(ssd);   
            }
            else
            {
                delay=0;
            }
            if (key == SW1)
            {
                if (feild_flag==0)
                {
                    min++; // Increment the min 
                    if (min >= 60) 
                    {     
                        min = 0; // Handle overflow
                    }
                }
                else
                {
                    hr++;
                    if(hr >= 24)
                    {
                        hr=0;
                    }
                }        
            }      
            else if (key == SW2)
            {
                if(feild_flag==0)
                {
                    min--; 
                    if (min >= 60) min = 59; 
                }
                else
                {
                    hr--; // Decrement the hr
                    if (hr >= 24) hr = 23; 
                }
            }
            else if(key== SW3)
            {
                feild_flag=!feild_flag;
            }
            else if (key == SW4)
            {
                TMR0 = 1; // Start timer
                oper_flag = 1; // Go to run mode
                min_fflag=1;
                hr_fflag=1;
                blink_flag=0;
                feild_flag=0;
            }
        } 
    } 
  }
         