#include <xc.h>
unsigned int count = 0,count3=0;
unsigned int flag = 1,blink_flag=1;


void __interrupt() ISR(void)
{
    if (TMR0IF)  // Check if Timer0 interrupt flag is set
    {

        TMR0 = 6;  

        // Increment count and toggle flag every 500 ms
        if (++count >= 20000)  // Adjust 20000 as needed
        {
            count = 0;
            flag = !flag;  // Toggle the flag state
        }

        TMR0IF = 0;  // Clear Timer0 interrupt flag
    }
    if(TMR2IF)
    {
        if(++count == 625)
        {
            blink_flag=!blink_flag;
        }
        TMR2IF=0;
    }
}
