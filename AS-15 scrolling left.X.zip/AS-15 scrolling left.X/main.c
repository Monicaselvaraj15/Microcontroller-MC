/*
 * File:   main.c
 * Author: Monica
 * Date : 06.08.24
 * Description: scorrling left
 *
 * Created on 5 August, 2024, 8:51 PM
 */


#include <xc.h>
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)
#include "ssd.h"

void init_config(void) 
{
    //Initializations here 
   init_ssd();
    
}
void main(void) 
{
    init_config();
    unsigned char ssd[4];
    unsigned char digit[]={ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,UNDERSCORE,UNDERSCORE};
    int wait=0,count=0;
    int i=0;
     
    while (1) 
    {
        if(wait++==200)
        {
            wait=0;
            if(count++ >= 11)
           {
            count=0;
           }
        }    
        ssd[0]=digit[count];
        ssd[1]=digit[(count+1)%12];
        ssd[2]=digit[(count+2)%12];
        ssd[3]=digit[(count+3)%12];
        i++;
        display(ssd);
        
        //Application code here 
    }
    return ;
}
