/*
 to toggle direction of train using digital keypad
 * File:   main.c
 * Name : Monica s
 * Date : 04.08.2024
 */

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

static void init_config(void) {
	
	/* Turn off LEDs initially */
	LED_ARRAY1 = 0x00;
	
	/* Configure as Ouput Port */
    	LED_ARRAY1_DDR  = 0X00;

	/* Initialize digital keypad */    	
	init_digital_keypad();
}

void main(void) {

    unsigned char key, flag = 1;
    unsigned int delay = 50000;
    int i,count;
    
    init_config();

    while(1)
    {

		/* read digital keypad value store it in variable called key */
        	key = read_digital_keypad(STATE);
	
		/* remember key  holds value of key when pressed and 0x3f when released */		
		if (key == SW1)
		{
            if( i > 0 && count ==0)
            {
                count++;
                flag = 0;
            }
        	/* take flag as variable to toggle the direction for pattern */
			flag = !flag;
        }           
		/* use if loops don't use blocking loops 
		   in blocking codes u cannot detect keys */				
		if (!delay--)
		{
            /* Code for left to right pattern */				            
            if (flag)      
			{
                if(count == 1)
                {
                    i = 0;
                    count++;
                }
                /*LED blinking from top to bottom*/  
                if (i < 8)                      
                {
                    delay = 50000;
                    LED_ARRAY1 = LED_ARRAY1 | (1 << i);
                    i++;                  
                }
                else if (i >= 8 && i < 16)                
                {
         
                    delay = 5000;
                    LED_ARRAY1 = LED_ARRAY1 & ~(1 << (i - 8));
                    i++;               
                }                        
                else if(i >= 16)
                {                    
                    if(count > 0)                                  
                       
                        i = 0;                                            
                    
                    delay = 5000;
                    
                    if(i <= 8 && count ==0  )               
                    {                                          
                        delay = 5000;                   
                        LED_ARRAY1 = LED_ARRAY1 | (1 << (8 - i));                   
                        i++;
                    }        
                
                    else if(i > 8 && i <= 16 && count == 0 )                   
                    {                 
                        delay = 5000;                   
                        LED_ARRAY1 = LED_ARRAY1 & ~(1 << ( 16 - i));                     
                        i++;                
                    }       
      
                    else if( i == 17)               
                    {          
                        
                        i = 0;                    
                                       
                    }
         
                }                        
                  
           }
        	/* Code for right to left pattern */						
            if (flag == 0)     		
			{
                count ++;
               
                if(i <= 8  )
                {
                    delay = 5000;
                    LED_ARRAY1 = LED_ARRAY1 | (1 << (8 -i));
                    i++;
                }        
                else if(i >= 8 && i <= 16 )    
                {
                    delay = 5000;
                    LED_ARRAY1 = LED_ARRAY1 & ~(1 << ( 16 - i));
                    i++;
                }       
                else if( i == 17)
                {
                    delay = 5000;
                    i = 0;                     
                }
					
			}
			
		}
    
    }
    return;
}