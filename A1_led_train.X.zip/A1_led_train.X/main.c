/*
 * File:   main.c
 * Name: monica.s
 * Date: 29.07.2024
 * Description: This program will toggle the LEDs at PORTD
 * It illustrates coding practices and conventions used in this course.
 */

#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)

/* Function: init_config()
 * Description: This function is used to setup initial peripheral
 * configuration, like setting port directions, initializing port values*/

static void init_config(void) {
    LED_ARRAY1_DDR = 0X00; // Set direction to o/p
    LED_ARRAY1 = 0X00;
    TRISB = 0X00;
    //PORTB = 0X00;// Set initial port value
}

void main(void) {
    unsigned int wait = 0;
    int i;
    init_config();

   while(1)
    {   
        /*non blocking delay*/
        if(wait++ == 10000)       
        {  
            wait = 0;
            if( i < 8)       //condition for left ON
            {           
                LED_ARRAY1 =  (LED_ARRAY1 << i)|1;                                                                      
                 i++;                                     
            } 
            else if(i > 7 && i < 16)      //condition for left OFF
            {                                                                                                                             
                LED_ARRAY1 = LED_ARRAY1 & ~(1 << (i - 8));                                                                                                                                           
                 i++;                                            
            }
            else if(i > 15 && i<24)       //condition for right ON
            {             
                LED_ARRAY1 = (LED_ARRAY1 >> 1)| 0x80;    
                i++;
            }
            else if(i > 23 && i <= 32) //condition for right OFF
            {                                                        
                LED_ARRAY1 = LED_ARRAY1 <<= 1; 
                 i++;
            }
            else if(i > 32)
            {
                i=0;
            } 
        }          
    } 
    

}

