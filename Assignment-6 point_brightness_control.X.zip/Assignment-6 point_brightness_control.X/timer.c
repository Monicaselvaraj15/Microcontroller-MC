#include <xc.h>
#include "timer.h"
void init_timer0(void)
{
    T0CS=0; //setting the clock source
    //set the presaclar
    PSA=1;
    
    TMR0=6;
    //Enable the timer0 interrupt
    TMR0IE=1;
    
    
}