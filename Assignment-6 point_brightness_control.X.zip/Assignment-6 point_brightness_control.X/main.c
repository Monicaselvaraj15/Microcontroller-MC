/*
 * File:   main.c
 * Author: Monica
 * Date:29.08.24
 *
 * Created on 28 August, 2024, 1:00 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "timer.h"
#include "main.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

#define PERIOD              100
void software_pwm(unsigned char key)
{
    static unsigned long int period = 100, loop_counter = 0, wait = 0, duty_cycle = 50;            
    while (1) 
    {        
       
        if (TMR0IE == 0)
        {
            duty_cycle = 10;
        }
        /*reading key pressed*/
        key = read_digital_keypad(LEVEL);
        
        if (wait-- == 0)
        {

            wait = 1000;

            if (key == SW1)
            {
                /*changing duty cycle to 100 on key press*/
                  duty_cycle=100;
                  
                  TMR0IE = 1;
                  
            }
            
        }
        /*50%-LED Blinking*/
        if (loop_counter < duty_cycle)
        {
            LED0 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            LED0 = 0;
        }
        if(loop_counter++ == period)
        {
            loop_counter = 0;
        }
        
    }
}
void init_config(void) {
    	
    LED_ARRAY1 = 0x00;    // off allLED
	LED_ARRAY1_DDR = 0x00;
    
    init_digital_keypad();
    init_timer0();
    
    /*Global interrupt enable*/
    GIE = 1;    
}
void main(void) {
    init_config();
    unsigned char key;
    
    while (1) {
        
        key = read_digital_keypad(LEVEL);       
        software_pwm(key);       
    }
    return;
}

    
