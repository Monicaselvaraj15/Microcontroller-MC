/*
 * File:   main.c
 * Author: Monica
 * Date:31.08.2024
 *
 * Created on 30 August, 2024, 8:38 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "uart.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) {
    //Initializations here 
    init_digital_keypad();
    init_uart(9600);
    puts("\n\rUART TEST CODE");
}
                
void main(void) 
{
    unsigned char key = 0;
unsigned int wait = 0;

init_config();

while (1) 
{
    // Application code here 
    key = read_digital_keypad(LEVEL);


        if(key == SW1 && wait==0)
        {
                
                puts("\n\rSW1 is pressed ");
                wait=1;
             
        }
        else if(key == SW2 && wait==1)
        {
           
            puts("\n\rSW2 is pressed");
            wait=0;
        }
        else if(key == SW3 && wait==0)
        {
           
            puts("\n\rSW3 is pressed");
            wait=1;
        }
        else if(key == SW4 && wait==1)
        {
            puts("\n\rSW4 is pressed");
            wait=0;
        }
    }
}


