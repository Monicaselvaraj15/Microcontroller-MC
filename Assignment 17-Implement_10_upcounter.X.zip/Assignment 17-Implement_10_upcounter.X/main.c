/*
 * File:   main.c
 * Author: Monica
 * Date:24.08.24
 *
 * Created on 24 August, 2024, 7:02 PM
 */


#include <xc.h>
#include "clcd.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) {
    //Initializations here 
    init_clcd();
}

void main(void) {
    init_config();
    unsigned int delay=0;
    char arr[]="0000000000";
    while (1) {
        //Application code here 
         clcd_print("Up Counter ",LINE1(0));
         clcd_print("Count:",LINE2(0));
       arr[9]++;
        for(int i=9; i>=0;i--)
        {
              
            if(arr[i] == ':')
            {
                arr[i-1]++;
                arr[i]='0';
                
              
            }
            
            
        }
         clcd_print(arr,LINE2(6));
         if(delay++==200)
         {
             delay=0;
         }
    }
    return ;

}
