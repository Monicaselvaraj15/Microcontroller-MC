#include <xc.h>
#include "timer.h"
void init_timer0(void)
{
    T0CS=0;
    //assigning presaclar
    PSA=1;
    
    TMR0=6;
    
    TMR0IE=1; //timer interrupt is enable
}
