#include <xc.h>
#include "main.h"


unsigned long int period = 100,duty_cycle,count=0;
void __interrupt() isr(void)
{        
    if (TMR0IF == 1)
    {
        /*50 percentage LED Blinking*/
        if(count < duty_cycle)
        {
            LED1 = ON;
        }
        if(count > duty_cycle)
        {
            LED1 =OFF;
        }
        if(count++ == period)
        {
            count = 0;
        }
        
        TMR0IF = 0;
    }
    

}

