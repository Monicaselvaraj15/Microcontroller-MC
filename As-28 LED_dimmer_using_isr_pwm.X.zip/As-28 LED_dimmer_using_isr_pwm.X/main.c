/*
 * File:   main.c
 * Author: Monica
 *Date:07.09:24
 * Created on 5 September, 2024, 6:29 PM
 */


#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "timer.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

extern unsigned  long int period;
extern unsigned  long int duty_cycle;
extern unsigned  long int count;
void init_config(void) 
{
    //Initializations here 
    LED_ARRAY1 = 0xFF;    
	LED_ARRAY1_DDR = 0x00;
   
    init_clcd();
    init_matrix_keypad();
    init_timer0();   
    
   
    GIE=1;
    
}

void main(void) 
{
    unsigned int wait=0,delay=0;
    unsigned char key=0;
    init_config();
    clcd_print("LED BRIGHTNESS:",LINE1(1));
     while (1) 
    {
        if (wait-- == 0) 
        {
            wait = 2500; // Main loop delay
        }
        
        if (delay-- == 0) 
        {
            delay = 300;  // Keypad scanning delay
            
            // Read key from user
            key = read_matrix_keypad(LEVEL);
            
            // LED brightness increments
            if (key == 1) 
            {
                if (duty_cycle < period) 
                {
                    duty_cycle++;
                }
            }
            // LED brightness decrements
            else if (key == 2) 
            {
                if (duty_cycle > 0) 
                {
                    duty_cycle--;
                }
            }
            
            // Update LED brightness bar on LCD
            unsigned char BAR = (duty_cycle * 10) / period;  
            for (int i = 0; i < 10; i++) 
            {
                if (i < BAR) 
                {
                    clcd_putch(0xFF, LINE2(i));  // Filled block
                } 
                else 
                {
                    clcd_putch(' ', LINE2(i));   // Empty block
                }
            }
        }
    }

}

