/*
 * File:   main.c
 * Author: Monica
 * Date:08.08.2024
 * Description:Implement a 4 digit key press counterAssignment
   
 *
 * Created on 8 August, 2024, 6:43 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#include "main.h"
#include "ssd.h"
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

void init_config(void) 
{
    //Initializations here 
     init_digital_keypad();          
     init_ssd();   
}

void main(void) 
{
  
    unsigned char key;
    unsigned char digits[10] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    unsigned char ssd[MAX_SSD_CNT];
    unsigned int delay = 0, count = 0;

      

    init_config();

   while(1)
    {                                              
       key = read_digital_keypad(LEVEL);                                     
      
           if(key == SW1)
           {
               delay++;
               if(delay > 200)
               {
                   count=0;
               }
           }
       
       else if(delay < 200 && delay !=0)
       {
           count++;
           delay=0;
       }
       else
       {
           delay=0;
       }
       
          ssd[0]=digits[count/1000];
          ssd[1]=digits[(count/100)%10];
          ssd[2]=digits[(count/10)%10];
          ssd[3]=digits[(count%10)];
          display(ssd);
       
    }
    return;
}
  

   


  


    