#ifndef MAIN_H
#define MAIN_H

#define LED7                RB7
#define LED_ARRAY1          PORTB
#define LED_ARRAY1_DDR      TRISB7

void adjust_led_blink_speed(unsigned int attempt);

#endif	/* MAIN_H */