/*
 * File:   main.c
 * Author: Monica
 * Date:09.09.24
 *
 * Created on 25 August, 2024, 11:39 AM
 */
#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "main.h"

#include <string.h>
#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)


static void init_config(void) 
{
    LED_ARRAY1_DDR = 0;
    LED_ARRAY1 = LED_ARRAY1 & 0x7F;
   
    init_clcd();
    init_matrix_keypad();
   
}

void main(void) 
{
    unsigned long delay = 0;
    unsigned int i = 0;
    unsigned char key = 0;
    unsigned char org_pswd[9] = "11110000";
    unsigned char usr_pswd[9] = {0}; // Initialize the user password array
    unsigned char cur_pos = 0, cur_key = 0, flag = 1;
    static unsigned int attempt = 5; // Number of attempts

    init_config();  // Initialize LCD, keypad, timer, etc.

    while (1) {
        key = read_matrix_keypad(STATE);

        if (key != ALL_RELEASED) 
        {
            cur_key = key;
        }

        clcd_print("Enter password", LINE1(0));

        // Blink cursor logic
        if (flag && cur_pos < 8) 
        {
            if (delay++ == 1) 
            {
                clcd_print("_", LINE2(cur_pos));
                delay = 0;
            } else {
                clcd_print(" ", LINE2(cur_pos));
            }
        }

        // Input password
        if (key == 1 && cur_pos < 8) {
            usr_pswd[i] = '1';
            clcd_putch('*', LINE2(cur_pos));
            cur_pos++;
            i++;  
        } else if (key == 2 && cur_pos < 8) {
            usr_pswd[i] = '0';
            clcd_putch('*', LINE2(cur_pos));
            cur_pos++;
            i++;  
        }
        
        
        if (i == 8) {
            // Compare passwords
            if (strcmp((char *)usr_pswd, (char *)org_pswd) == 0) {
                clear_screen();
                clcd_print("GREAT! YOU HAVE", LINE1(0));
                clcd_print("CRACKED THE CODE", LINE2(0));
                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                __delay_us(9000000);
                LED7=0;
                
                
            } else 
            {
                

                attempt--;  // Decrement attempt count                
                
                if (attempt == 0)
                {
                    clear_screen();
                    clcd_print("PASSWORD FAILED", LINE1(0));
                    clcd_print("RESET THE PASSWORD", LINE2(0));
                    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                    __delay_us(9000000);
                    break;  // Exit loop or halt after failed attempts
                } else 
                {
                    clear_screen();
                    clcd_print("WRONG PASSWORD", LINE1(0));
                    __delay_us(550000);
                    clcd_print("Attempts left: ", LINE1(0));
                    clcd_putch((attempt % 10) + '0', LINE2(1));  
                    __delay_us(550000);
                    clear_screen();
                    
                    
                }
                
 
               
            }

            // Reset password entry variables
            cur_pos = 0;
            i = 0;
        }
        if(attempt==4)
        {
            LED7=!LED7;
            __delay_us(5);
        }
        else if(attempt==3)
        {
            LED7=!LED7;
            __delay_us(4);
        }
        else if(attempt==2)
        {
             LED7=!LED7;
            __delay_us(3);
        }
        else if(attempt==1)
        {
             LED7=!LED7;
            __delay_us(2);
        }
    }
}

